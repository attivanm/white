﻿namespace Northwind.Framework.Windows
{
    public enum EmploymentType
    {
        FullTime,
        PartTime
    }
}
