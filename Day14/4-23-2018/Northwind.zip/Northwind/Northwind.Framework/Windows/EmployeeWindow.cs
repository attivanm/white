﻿using Northwind.Framework.Engine;
using TestStack.White.UIItems;
using TestStack.White.UIItems.WindowItems;

namespace Northwind.Framework.Windows
{
    public class EmployeeWindow : WindowObjects
    {
        #region Controld
        private Button CancelButton => Button("Cancel");
        #endregion

        public EmployeeWindow(Window window) 
            : base(window)
        {

        }

        public void Cancel()
        {
            CancelButton.Click();
        }
    }
}
