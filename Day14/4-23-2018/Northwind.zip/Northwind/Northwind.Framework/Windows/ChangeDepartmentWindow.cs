﻿using Northwind.Framework.Engine;
using TestStack.White.UIItems;
using TestStack.White.UIItems.ListBoxItems;
using TestStack.White.UIItems.WindowItems;

namespace Northwind.Framework.Windows
{
    public class ChangeDepartmentWindow : WindowObjects
    {
        #region Controls
        private ListBox DepartmentList => ListBox();
        private Button Ok => Button("OK");
        #endregion

        public ChangeDepartmentWindow(Window window)
            : base(window)
        {
        }

        public void SelectDepartment(string deptoName)
        {
            DepartmentList.Items.Select(deptoName);
            Ok.Click();
        }
    }
}
