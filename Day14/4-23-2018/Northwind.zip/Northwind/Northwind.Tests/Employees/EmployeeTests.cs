﻿using Northwind.Framework.Engine;
using Northwind.Framework.Windows;
using Northwind.Tests.Base;
using Northwind.Utils;
using NUnit.Framework;

namespace Northwind.Tests.Employees
{
    [TestFixture]
    public class EmployeeTests : BaseTest
    {
        [Test]
        public void Can_Create_Employee()
        {
            //Variables
            var deptoName = DataGenerator.Name;
            //...

            //PreConditions
            //REST - NO
            //DB - YES using EF (Entity Framework)
            WindowRepository.Main.AddDepartment();
            WindowRepository.Department.CreateDepartment(deptoName);

            //Test Steps
            WindowRepository.Main.AddEmployee();
            WindowRepository.NewEmployee
                .SetFirstName("Gonzalo")
                .SetLastName("Alba")
                .SetEmploymentType(EmploymentType.FullTime)
                .SetAbout("About me...")
                .SetDepartment(deptoName)
                .Save();

            WindowRepository.Employee.Cancel();

            Assert.IsTrue(
                WindowRepository.Main.IsEmployeeInGrid("Gonzalo",
                "Alba", deptoName),
                "Created Employee is not in the grid.");
        }
    }
}
