﻿using Northwind.Acceptance.Dtos;
using System.Collections.Generic;

namespace Northwind.Acceptance.Utils
{
    public class ContextData
    {
        public DepartmentDto DepartmentDto { get; set; }
        public IEnumerable<DepartmentDto> DepartmentDtos { get; set; }
        

    }
}
