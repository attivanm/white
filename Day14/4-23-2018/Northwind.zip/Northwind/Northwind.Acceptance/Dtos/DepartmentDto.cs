﻿using Northwind.Acceptance.Util;

namespace Northwind.Acceptance.Dtos
{
    public class DepartmentDto
    {
        private string _name;
        public string Name
        {
            get { return _name; }
            set { _name = SetterManager.Set(value); }
        }
    }
}
