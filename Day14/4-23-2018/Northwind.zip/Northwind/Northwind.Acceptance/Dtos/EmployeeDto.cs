﻿using Northwind.Acceptance.Util;

namespace Northwind.Acceptance.Dtos
{
    public class EmployeeDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EmployeeType { get; set; }
        public string About { get; set; }

        private string _departmentName;
        public string DepartmentName
        {
            get { return _departmentName; }
            set { _departmentName = SetterManager.Set(value); }
        }

    }
}
