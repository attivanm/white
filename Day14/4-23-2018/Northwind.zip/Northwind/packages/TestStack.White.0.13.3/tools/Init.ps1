﻿param($installPath, $toolsPath, $package)

Import-Module (Join-Path $toolsPath TestStack.White.psm1)